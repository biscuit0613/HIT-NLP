# Copyright (c) 2019 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Gradient-accumulation variant of train.py (for review / 8GB-card use).

Differences from train.py:
1. An `--accum_steps` switch is registered in __main__ (transformer.yaml is
   left untouched);
2. The `accumulate_windows` helper groups every accum_steps micro-batches
   into one optimizer step;
3. Each micro-batch backprops `sum_cost / window_token_num`, so the summed
   gradients equal the gradient of ONE big batch holding all micro-batches
   -- with accum_steps=1 the behaviour is identical to train.py.

Example (8GB card): --batch_size 2048 --accum_steps 2 keeps the effective
4096-token batch, the per-step LR schedule and the total optimizer steps
unchanged, while roughly halving the activation memory.
"""
import logging
import os
import time

import numpy as np
import paddle

import reader
from transformer import TransformerModel
from utils.configure import PDConfig
from utils.check import check_gpu, check_version


def accumulate_windows(micro_batch_gen, accum_steps):
    """
    Group every `accum_steps` micro-batches (lists of numpy arrays yielded
    by the reader) into one optimization window, and count the total number
    of real (non-padding) target tokens of the window from lbl_weight, so
    gradients can be normalized exactly like a single big batch. The
    remainder at the end of the generator is flushed as a smaller window.
    """
    window, window_token_num = [], 0
    for data_inputs in micro_batch_gen:
        window.append(data_inputs)
        # data_inputs[-1] is lbl_weight, 1.0 on real tokens, 0.0 on pads.
        window_token_num += int(data_inputs[-1].sum())
        if len(window) == accum_steps:
            yield window, window_token_num
            window, window_token_num = [], 0
    if window:
        yield window, window_token_num


def do_train(args):
    if args.use_cuda:
        paddle.set_device('gpu')
    else:
        paddle.set_device('cpu')

    # define the data generator
    processor = reader.DataProcessor(
        fpattern=args.training_file,
        src_vocab_fpath=args.src_vocab_fpath,
        trg_vocab_fpath=args.trg_vocab_fpath,
        token_delimiter=args.token_delimiter,
        use_token_batch=args.use_token_batch,
        batch_size=args.batch_size,
        device_count=1,
        pool_size=args.pool_size,
        sort_type=args.sort_type,
        shuffle=args.shuffle,
        shuffle_batch=args.shuffle_batch,
        start_mark=args.special_token[0],
        end_mark=args.special_token[1],
        unk_mark=args.special_token[2],
        max_length=args.max_length,
        n_head=args.n_head)
    batch_generator = processor.data_generator(phase="train")
    args.src_vocab_size, args.trg_vocab_size, args.bos_idx, args.eos_idx, \
        args.unk_idx = processor.get_vocab_summary()

    random_seed = eval(str(args.random_seed))
    if random_seed is not None:
        paddle.seed(random_seed)

    # define the model

    model = TransformerModel.from_args(args)
    model.train()

    # define the optimizer

    scheduler = paddle.optimizer.lr.NoamDecay(
        d_model=args.d_model,
        warmup_steps=args.warmup_steps,
        learning_rate=args.learning_rate,
        last_epoch=0)
    optimizer = paddle.optimizer.Adam(
        learning_rate=scheduler,
        beta1=args.beta1,
        beta2=args.beta2,
        epsilon=float(args.eps),
        parameters=model.parameters())

    assert (args.init_from_checkpoint == "") or (
        args.init_from_pretrain_model == "")

    ## init from some checkpoint, to resume the previous training
    if args.init_from_checkpoint:
        model.set_state_dict(
            paddle.load(
                os.path.join(args.init_from_checkpoint,
                             "transformer.pdparams")))
        optimizer.set_state_dict(
            paddle.load(
                os.path.join(args.init_from_checkpoint, "transformer.pdopt")))
        print("finish initing model from checkpoint from %s" %
              (args.init_from_checkpoint))

    ## init from some pretrain models, to better solve the current task
    if args.init_from_pretrain_model:
        model.set_state_dict(
            paddle.load(
                os.path.join(args.init_from_pretrain_model,
                             "transformer.pdparams")))
        print("finish initing model from pretrained params from %s" %
              (args.init_from_pretrain_model))

    # the best cross-entropy value with label smoothing
    loss_normalizer = -(
        (1. - args.label_smooth_eps) * np.log(
            (1. - args.label_smooth_eps)) + args.label_smooth_eps *
        np.log(args.label_smooth_eps / (args.trg_vocab_size - 1) + 1e-20))
    # start training

    # Gradient accumulation: accum_steps micro-batches share one optimizer
    # step. step_idx / batch_id / print_step / save_step / max_iter below all
    # count optimizer steps (windows), not raw micro-batches.
    accum_steps = max(1, int(getattr(args, "accum_steps", 1)))

    step_idx = 0
    total_batch_num = 0  # this is for benchmark
    for pass_id in range(args.epoch):
        batch_id = 0
        for window, window_token_num in accumulate_windows(
                batch_generator(), accum_steps):
            if args.max_iter and total_batch_num == args.max_iter:  # this for benchmark
                return

            window_sum_cost = 0.
            for data_inputs in window:
                src_word, src_pos, src_slf_attn_bias, trg_word, trg_pos, \
                    trg_slf_attn_bias, trg_src_attn_bias, lbl_word, \
                    lbl_weight = [paddle.to_tensor(x) for x in data_inputs]

                sum_cost, avg_cost, token_num = model(
                    src_word, src_pos, src_slf_attn_bias, trg_word, trg_pos,
                    trg_slf_attn_bias, trg_src_attn_bias, lbl_word,
                    lbl_weight)

                # Divide by the token count of the WHOLE window (not of this
                # micro-batch), so the gradients accumulated over the window
                # equal the gradient of one big batch of window_token_num
                # tokens. With accum_steps=1 this reduces to
                # backward(avg_cost) of train.py.
                (sum_cost / window_token_num).backward()
                window_sum_cost += float(sum_cost)

            optimizer.step()
            optimizer.clear_grad()
            scheduler.step()

            if step_idx % args.print_step == 0:
                total_avg_cost = window_sum_cost / window_token_num

                if step_idx == 0:
                    logging.info(
                        "step_idx: %d, epoch: %d, batch: %d, avg loss: %f, "
                        "normalized loss: %f, ppl: %f" %
                        (step_idx, pass_id, batch_id, total_avg_cost,
                         total_avg_cost - loss_normalizer,
                         np.exp([min(total_avg_cost, 100)])))
                    avg_batch_time = time.time()
                else:
                    logging.info(
                        "step_idx: %d, epoch: %d, batch: %d, avg loss: %f, "
                        "normalized loss: %f, ppl: %f, speed: %.2f step/s" %
                        (step_idx, pass_id, batch_id, total_avg_cost,
                         total_avg_cost - loss_normalizer,
                         np.exp([min(total_avg_cost, 100)]),
                         args.print_step / (time.time() - avg_batch_time)))
                    avg_batch_time = time.time()

            if step_idx % args.save_step == 0 and step_idx != 0:
                if args.save_model_path:
                    model_path = os.path.join(args.save_model_path,
                                              "step_" + str(step_idx),
                                              "transformer")
                    paddle.save(model.state_dict(), model_path + ".pdparams")
                    paddle.save(optimizer.state_dict(), model_path + ".pdopt")

            batch_id += 1
            step_idx += 1
            total_batch_num = total_batch_num + 1  # this is for benchmark

    if args.save_model_path:
        model_path = os.path.join(args.save_model_path, "step_final",
                                  "transformer")
        paddle.save(model.state_dict(), model_path + ".pdparams")
        paddle.save(optimizer.state_dict(), model_path + ".pdopt")


if __name__ == "__main__":
    args = PDConfig(yaml_file="./transformer.yaml")
    # Register the gradient-accumulation switch on top of transformer.yaml
    # (must be appended before build(); the yaml file itself stays as-is).
    args += ('accum_steps', int, 1,
             'The number of micro-batches whose gradients are accumulated '
             'before one optimizer step.')
    args.build()
    args.Print()
    check_gpu(args.use_cuda)
    check_version()

    do_train(args)
